# Hex sample store

Upload this ZIP to Hex. The test expects the Next.js framework header to be disabled. The sample intentionally enables it, so the original fails and the patched copy should pass.
