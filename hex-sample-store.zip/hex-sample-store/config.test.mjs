import test from 'node:test';
import assert from 'node:assert/strict';
import config from './next.config.mjs';

test('the store disables the framework identification header', () => {
  assert.equal(config.poweredByHeader, false);
});
