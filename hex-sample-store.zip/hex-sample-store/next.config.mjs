export default { poweredByHeader: true };
