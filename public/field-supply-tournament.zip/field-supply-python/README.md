# Field Supply

A standalone, dependency-free Python demo storefront with a product catalog, cart and simulated checkout. It uses in-memory sessions and contains no real products, accounts, or payments.

Run `python app.py` from this folder and open http://127.0.0.1:8080. Run `python -m unittest -v` to exercise checkout and check the five intentionally missing security settings. The checkout test should pass. The security tests are expected to fail in this baseline.

This example is intended for local practice and binds to loopback.
