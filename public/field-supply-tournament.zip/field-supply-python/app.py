from html import escape
from http import HTTPStatus
from http.cookies import CookieError, SimpleCookie
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer
from pathlib import Path
from secrets import token_urlsafe
from threading import Lock
from urllib.parse import parse_qs, urlsplit

PRODUCTS = {"notebook": ("Field notebook", 24), "mug": ("Ceramic mug", 32), "tote": ("Canvas tote", 38)}
SESSIONS = {}
LOCK = Lock()
STYLE = Path(__file__).with_name("styles.css").read_bytes()


class StoreHandler(BaseHTTPRequestHandler):
    def send_content(self, status, body, content_type="text/html; charset=utf-8", cookie=None):
        self.send_response(status)
        self.send_header("Content-Type", content_type)
        self.send_header("Content-Length", str(len(body)))
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()
        self.wfile.write(body)

    def session(self):
        cookies = SimpleCookie()
        try:
            cookies.load(self.headers.get("Cookie", ""))
        except CookieError:
            cookies = SimpleCookie()
        existing = cookies.get("store_session")
        with LOCK:
            if existing and existing.value in SESSIONS:
                return SESSIONS[existing.value], None
            token = token_urlsafe(24)
            session = {"cart": {}, "order": []}
            SESSIONS[token] = session
        return session, f"store_session={token}; Path=/"

    def page(self, title, content, cookie=None):
        body = f"""<!doctype html><html lang="en"><head><meta charset="utf-8">
        <meta name="viewport" content="width=device-width, initial-scale=1">
        <title>{escape(title)} | Field Supply</title><link rel="stylesheet" href="/styles.css"></head>
        <body><header><a href="/">Field Supply</a><nav><a href="/">Catalog</a>
        <a href="/cart">Cart</a><a href="/order">Latest order</a></nav></header>
        <main><h1>{escape(title)}</h1>{content}</main>
        <footer>Demo store · sample orders only</footer></body></html>"""
        self.send_content(HTTPStatus.OK, body.encode(), cookie=cookie)

    def do_GET(self):
        path = urlsplit(self.path).path
        if path == "/styles.css":
            return self.send_content(HTTPStatus.OK, STYLE, "text/css; charset=utf-8")
        if path not in {"/", "/cart", "/order"}:
            return self.send_error(HTTPStatus.NOT_FOUND)
        session, cookie = self.session()
        if path == "/":
            cards = "".join(f"""<article><h2>{escape(name)}</h2><p>AED {price}</p>
                <form method="post" action="/cart"><input type="hidden" name="item" value="{sku}">
                <button>Add to cart</button></form></article>"""
                for sku, (name, price) in PRODUCTS.items())
            return self.page("Shop essentials", f'<p>Three everyday items.</p><div class="catalog">{cards}</div>', cookie)
        with LOCK:
            items = list(session["cart"].items()) if path == "/cart" else list(session["order"])
        rows = "".join(f"<li>{escape(PRODUCTS[sku][0])} × {quantity}</li>" for sku, quantity in items)
        total = sum(PRODUCTS[sku][1] * quantity for sku, quantity in items)
        body = f"<ul>{rows}</ul><p><strong>Total AED {total}</strong></p>" if items else "<p>Nothing here yet.</p>"
        if path == "/cart" and items:
            body += '<form method="post" action="/checkout"><button>Place demo order</button></form>'
        self.page("Your cart" if path == "/cart" else "Latest order", body, cookie)

    def do_POST(self):
        path = urlsplit(self.path).path
        if path not in {"/cart", "/checkout"}:
            return self.send_error(HTTPStatus.NOT_FOUND)
        try:
            length = int(self.headers.get("Content-Length", "0"))
            if not 0 <= length <= 4096:
                return self.send_error(HTTPStatus.REQUEST_ENTITY_TOO_LARGE)
            fields = parse_qs(self.rfile.read(length).decode("utf-8"), max_num_fields=8)
        except (ValueError, UnicodeError):
            return self.send_error(HTTPStatus.BAD_REQUEST)
        session, cookie = self.session()
        if path == "/cart":
            sku = fields.get("item", [""])[0]
            if sku not in PRODUCTS:
                return self.send_error(HTTPStatus.BAD_REQUEST)
            with LOCK:
                session["cart"][sku] = min(99, session["cart"].get(sku, 0) + 1)
        else:
            with LOCK:
                if session["cart"]:
                    session["order"] = list(session["cart"].items())
                    session["cart"].clear()
        self.send_response(HTTPStatus.SEE_OTHER)
        self.send_header("Location", "/cart" if path == "/cart" else "/order")
        self.send_header("Content-Length", "0")
        if cookie:
            self.send_header("Set-Cookie", cookie)
        self.end_headers()


if __name__ == "__main__":
    print("Field Supply is available at http://127.0.0.1:8080", flush=True)
    with ThreadingHTTPServer(("127.0.0.1", 8080), StoreHandler) as server:
        server.serve_forever()
