import http.client
from http.server import ThreadingHTTPServer
from threading import Thread
import unittest

from app import StoreHandler


class StoreTests(unittest.TestCase):
    @classmethod
    def setUpClass(cls):
        cls.server = ThreadingHTTPServer(("127.0.0.1", 0), StoreHandler)
        cls.worker = Thread(target=cls.server.serve_forever, daemon=True)
        cls.worker.start()

    @classmethod
    def tearDownClass(cls):
        cls.server.shutdown()
        cls.server.server_close()
        cls.worker.join()

    def request(self, path, method="GET", body=None, cookie=None):
        connection = http.client.HTTPConnection("127.0.0.1", self.server.server_port, timeout=3)
        headers = {"Cookie": cookie} if cookie else {}
        try:
            connection.request(method, path, body, headers)
            response = connection.getresponse()
            return response.status, dict(response.getheaders()), response.read().decode()
        finally:
            connection.close()

    def test_cart_and_checkout(self):
        status, headers, catalog = self.request("/")
        self.assertEqual(status, 200)
        self.assertIn("Field notebook", catalog)
        cookie = headers["Set-Cookie"].split(";", 1)[0]
        self.assertEqual(self.request("/cart", "POST", "item=notebook", cookie)[0], 303)
        self.assertIn("Field notebook", self.request("/cart", cookie=cookie)[2])
        self.assertEqual(self.request("/checkout", "POST", "", cookie)[0], 303)
        self.assertIn("Field notebook", self.request("/order", cookie=cookie)[2])

    def test_session_cookie_is_http_only(self):
        self.assertIn("HttpOnly", self.request("/")[1]["Set-Cookie"])

    def test_session_cookie_declares_same_site(self):
        self.assertIn("SameSite=Lax", self.request("/")[1]["Set-Cookie"])

    def test_pages_prevent_framing(self):
        self.assertEqual(self.request("/")[1].get("X-Frame-Options"), "DENY")

    def test_private_order_is_not_cacheable(self):
        self.assertIn("no-store", self.request("/order")[1].get("Cache-Control", ""))

    def test_pages_disable_mime_sniffing(self):
        self.assertEqual(self.request("/")[1].get("X-Content-Type-Options"), "nosniff")


if __name__ == "__main__":
    unittest.main()
